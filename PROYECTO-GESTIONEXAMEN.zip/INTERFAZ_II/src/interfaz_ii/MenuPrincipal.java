package interfaz_ii;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JLayeredPane;
import javax.swing.SwingConstants;

public class MenuPrincipal extends javax.swing.JFrame {

    public MenuPrincipal() {
        initComponents();
         setSize(1220, 830);
         setLocationRelativeTo(null);
         FondoImagen.aplicarImagen(Contenedor, "/interfaz_ii/imagen/Fondo_1.png");
         
         
         titulo.setOpaque(true); // Asegura que se vea el fondo
        titulo.setBackground(new Color(0, 0, 0, 150)); // Negro con transparencia
        titulo.setForeground(Color.WHITE); // Texto blanco para contraste
        
        
        Contenedor.addComponentListener(new java.awt.event.ComponentAdapter() {
    public void componentResized(java.awt.event.ComponentEvent evt) {
        titulo.setBounds(0, 50, Contenedor.getWidth(), 68); // Se adapta al ancho del contenedor
    }
});
        titulo.setHorizontalAlignment(SwingConstants.CENTER); // Centra el texto


    }
    

public class FondoImagen {
    public static void aplicarImagen(JDesktopPane contenedor, String rutaImagen) {
        Image imagen = new ImageIcon(FondoImagen.class.getResource(rutaImagen)).getImage();

        JComponent fondo = new JComponent() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (imagen != null) {
                    g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this); // Escala al tamaño del contenedor
                }
            }
        };

        fondo.setBounds(0, 0, contenedor.getWidth(), contenedor.getHeight());
        fondo.setOpaque(false);
        contenedor.add(fondo, JLayeredPane.FRAME_CONTENT_LAYER); // Agrega al fondo
        contenedor.repaint();

        contenedor.addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override
            public void componentResized(java.awt.event.ComponentEvent e) {
                fondo.setSize(contenedor.getSize());
                contenedor.repaint();
            }
        });
    }
}
    
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Contenedor = new javax.swing.JDesktopPane();
        titulo = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        Asignar = new javax.swing.JMenuItem();
        REPORT = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Contenedor.setPreferredSize(new java.awt.Dimension(1120, 697));

        titulo.setBackground(new java.awt.Color(0, 0, 0));
        titulo.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        titulo.setForeground(new java.awt.Color(255, 255, 255));
        titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titulo.setText("GESTION DE EXAMEN");
        titulo.setOpaque(true);
        Contenedor.add(titulo);
        titulo.setBounds(0, 20, 1220, 68);

        jMenu1.setText("REGISTRO");

        jMenuItem1.setText("ALUMNO");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        Asignar.setText("AULAS");
        Asignar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AsignarActionPerformed(evt);
            }
        });
        jMenu1.add(Asignar);

        REPORT.setText("REPORTE");
        REPORT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                REPORTActionPerformed(evt);
            }
        });
        jMenu1.add(REPORT);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Contenedor, javax.swing.GroupLayout.DEFAULT_SIZE, 1220, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Contenedor, javax.swing.GroupLayout.DEFAULT_SIZE, 807, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    
    
    
    
    
    private void AsignarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AsignarActionPerformed
          asignarSilla_2 cli = new asignarSilla_2(Contenedor);
    Contenedor.add(cli);
    cli.setVisible(true);

    // Centrado
    int x = (Contenedor.getWidth() - cli.getWidth()) / 2;
    int y = (Contenedor.getHeight() - cli.getHeight()) / 2 + 50;
    cli.setLocation(x, y);
    }//GEN-LAST:event_AsignarActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        Registro_Alum cli = new Registro_Alum(Contenedor); // Pasa el JDesktopPane
        Contenedor.add(cli);
        cli.setVisible(true);
        int x = (Contenedor.getWidth() - cli.getWidth()) / 2;
        int y = (Contenedor.getHeight() - cli.getHeight()) / 2+50;
        cli.setLocation(x, y);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void REPORTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_REPORTActionPerformed

        ReporteVisualAulas cli = new ReporteVisualAulas(); // sin parámetros
Contenedor.add(cli);
cli.setVisible(true);
int x = (Contenedor.getWidth() - cli.getWidth()) / 2;
int y = (Contenedor.getHeight() - cli.getHeight()) / 2 + 50;
cli.setLocation(x, y);
        
    }//GEN-LAST:event_REPORTActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem Asignar;
    private javax.swing.JDesktopPane Contenedor;
    private javax.swing.JMenuItem REPORT;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables
}
