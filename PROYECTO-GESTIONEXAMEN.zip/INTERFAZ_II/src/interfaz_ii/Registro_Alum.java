
package interfaz_ii;
import java.sql.SQLException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

//import com.sun.jdi.connect.spi.Connection;
import java.awt.BorderLayout;
import java.io.File;
import java.io.FileInputStream;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import java.awt.FlowLayout;
//import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.LinearGradientPaint;
//import java.awt.RadialGradientPaint;
//import java.awt.RenderingHints;
import java.awt.geom.Point2D;
//import java.io.BufferedWriter;
import java.io.FileOutputStream;
//import java.io.FileWriter;
//import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.poi.ss.usermodel.*; // <-- para Workbook, Sheet, Row, Cell, etc.
import org.apache.poi.hssf.usermodel.HSSFWorkbook; // para archivos .xls (antiguos)
import org.apache.poi.xssf.usermodel.XSSFWorkbook; // para archivos .xlsx (modernos)

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Point2D;

import javax.swing.table.DefaultTableModel;
public class Registro_Alum extends javax.swing.JInternalFrame {

public DefaultTableModel Tabla;
    

    
public Registro_Alum() {
    
    
    initComponents();
        setClosable(true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setSize(800, 600);

        // Crear el fondo degradado
        JPanel fondo = new jPanelGradient();
        fondo.setLayout(new BorderLayout());

        // Crear el panel principal donde van los componentes (combos, textos, etc.)
        JPanel Panel_Principal = new JPanel();
        Panel_Principal.setOpaque(false); // <- Si quieres transparencia sobre el fondo

        // Puedes usar otro layout si prefieres: GridLayout, BoxLayout, etc.
        Panel_Principal.setLayout(new FlowLayout());

        // Aquí puedes agregar temporalmente un combo para prueba
        JComboBox<String> comboPrueba = new JComboBox<>(new String[]{"Uno", "Dos", "Tres"});
        Panel_Principal.add(comboPrueba);

        // Agregar al fondo degradado
        fondo.add(Panel_Principal, BorderLayout.CENTER);

        // Aplicar como contenido del JInternalFrame
        setContentPane(fondo);

        // Cargar datos en los combos
     //   llenarCombos();
     try (Connection conn = DriverManager.getConnection("jdbc:h2:~/basedatos", "sa", "");
         Statement stmt = conn.createStatement()) {

        String sqlCreate = "CREATE TABLE IF NOT EXISTS DATOS_IMPORTADOS ("
            + "codigo VARCHAR(20), apellido VARCHAR(100), opcion1 VARCHAR(100), opcion2 VARCHAR(100),"
            + "modalidad VARCHAR(50), dni VARCHAR(20), sede VARCHAR(50), inscripcion DATE, procedencia VARCHAR(100),"
            + "cod_colegio VARCHAR(20), fecha_egreso DATE, tipo_colegio VARCHAR(50), ubigeo_colegio VARCHAR(20),"
            + "estado_civil VARCHAR(20), sexo VARCHAR(20), nombre_colegio VARCHAR(100), idioma_nativo VARCHAR(50),"
            + "celular VARCHAR(20), direccion VARCHAR(150), ubigeo VARCHAR(20), fecha_nacimiento DATE,"
            + "termino_secundaria VARCHAR(20), observacion VARCHAR(255), usuario VARCHAR(50))";

        stmt.execute(sqlCreate);

    } catch (SQLException e) {/*
        JOptionPane.showMessageDialog(this, "Error al crear la tabla: " + e.getMessage());
    */}
    
    
    
    }
class jPanelGradient extends JPanel {
    protected void paintComponent(Graphics g) {
    
  super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            int w = getWidth(), h = getHeight();
            Color color1 = new Color(0, 0, 0);        // Negro
            Color color2 = new Color(4, 143, 57);     // Verde
            Color color3 = new Color(0, 0, 0);        // Negro
            Point2D start = new Point2D.Float(0, 0);
            Point2D end = new Point2D.Float(0, h);
            float[] dist = {0.0f, 0.5f, 1.0f};
            Color[] colors = {color1, color2, color3};
            LinearGradientPaint p = new LinearGradientPaint(start, end, dist, colors);
            g2d.setPaint(p);
            g2d.fillRect(0, 0, w, h);
       
        
         
    
    
} 
}
  

/*
private void llenarCombos() {
        String[] carreras = {
            "Selecionar",
            "Escuela profesional de Agronomía",
            "Escuela profesional de Zootecnia",
            "Escuela profesional de Ingeniería en Industrias Alimentarias",
            "Escuela profesional de Ingeniería Forestal",
            "Escuela profesional de Ingeniería en Conservación de Suelos y Agua",
            "Escuela profesional de Administración",
            "Escuela profesional de Contabilidad",
            "Escuela profesional de Economía",
            "Escuela profesional de Ingeniería en Informática y Sistemas",
            "Escuela profesional de Ingeniería Ambiental",
            "Escuela profesional de Ingeniería en Recursos Naturales Renovables",
            "Escuela profesional de Ingeniería Mecánica Eléctrica",
            "Escuela profesional de Ingeniería Civil",
            "Escuela profesional de Turismo y Hotelería",
            "Escuela profesional de Ingeniería en Ciberseguridad"
        };

        String[] modalidades = {
            "Selecionar",
            "Víctima de terrorismo",
            "Arte y cultura",
            "Beca 18",
            "Modalidad ordinario",
            "Personas con discapacidad",
            "Centro Preuniversitario",
            "Exonerados primeros puestos",
            "Exonerados traslado interno",
            "Deportista calificado",
            "No definido"
        };

        String[] tiposColegio = {
            "Selecionar",
            "Nacional",
            "Particular",
            "Parroquial",
            "Otro"
        };

        String[] estadosCiviles = {
            "Selecionar",
            "Soltero",
            "Casado",
            "Divorciado",
            "Viudo",
            "Conviviente",
            "Separado",
            "Unión civil"
        };

        String[] sexos = {
            "Selecionar",
            "Masculino",
            "Femenino",
            "No binario",
            "Agénero",
            "Género fluido",
            "Bigénero",
            "Trigénero",
            "Demiboy",
            "Demigirl",
            "Neutrois",
            "Maverique",
            "Pangénero",
            "Poligénero",
            "Intergénero",
            "Andrógino",
            "Apogénero",
            "Genderflux",
            "Género cuestionante",
            "Aliagender",
            "Género expansivo",
            "Otro"
        };

        String[] secundaria = {
            "Selecionar",
            "Concluido",
            "No concluido"
        };

        String[] Año = {
            "Seleccionar",
            "2023",
            "2024"
        };

        // Aquí deberías tener definidos los JComboBox como atributos
        // Ejemplo:
        cbxOpcion1.setModel(new DefaultComboBoxModel<>(carreras));
        cbxOpcion2.setModel(new DefaultComboBoxModel<>(carreras));
        cbxModalidad.setModel(new DefaultComboBoxModel<>(modalidades));
        cbxTipoColegio.setModel(new DefaultComboBoxModel<>(tiposColegio));
        cbxEstadoCivil.setModel(new DefaultComboBoxModel<>(estadosCiviles));
        cbxSexo.setModel(new DefaultComboBoxModel<>(sexos));
        cbxSecundaria.setModel(new DefaultComboBoxModel<>(secundaria));
         xd.setModel(new DefaultComboBoxModel<>(Año));
    }*/


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Panel_Principal = new jPanelGradient();
        botones = new javax.swing.JPanel();
        Btn_Agregar = new javax.swing.JButton();
        Btn_Editar = new javax.swing.JButton();
        Btn_Eliminar = new javax.swing.JButton();
        Importar = new javax.swing.JButton();
        Exportar_btn = new javax.swing.JButton();
        Btn_EliminarTabla = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tbl = new javax.swing.JTable();
        titulo = new javax.swing.JLabel();
        campo = new javax.swing.JPanel();
        txtCodigo = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cbxOpcion1 = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        cbxOpcion2 = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        cbxModalidad = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        txtSede = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtDNI = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        dateEgresoColegio = new com.toedter.calendar.JDateChooser();
        cbxTipoColegio = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtUbiColegio = new javax.swing.JTextField();
        txtIdioma = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        txtNomColegio = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        txtObservacion = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        cbxSecundaria = new javax.swing.JComboBox<>();
        jLabel22 = new javax.swing.JLabel();
        cbxSexo = new javax.swing.JComboBox<>();
        jLabel23 = new javax.swing.JLabel();
        txtUbigeo = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        dateNacimiento = new com.toedter.calendar.JDateChooser();
        jLabel25 = new javax.swing.JLabel();
        cbxEstadoCivil = new javax.swing.JComboBox<>();
        jLabel26 = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        dateInscripcion = new com.toedter.calendar.JDateChooser();
        jLabel16 = new javax.swing.JLabel();
        txtProcedencia = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        txtCodColegio = new javax.swing.JTextField();
        xd = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();

        setBackground(new java.awt.Color(0, 0, 0));
        setClosable(true);
        setPreferredSize(new java.awt.Dimension(1144, 750));

        Panel_Principal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 51)));
        Panel_Principal.setForeground(new java.awt.Color(0, 153, 0));
        Panel_Principal.setOpaque(false);

        botones.setBackground(new java.awt.Color(0, 0, 28));
        botones.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 51)));

        Btn_Agregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/interfaz_ii/agregar-usuario (4).png"))); // NOI18N
        Btn_Agregar.setText(" Agregar");
        Btn_Agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_AgregarActionPerformed(evt);
            }
        });

        Btn_Editar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/interfaz_ii/editar (2).png"))); // NOI18N
        Btn_Editar.setText("Editar");
        Btn_Editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_EditarActionPerformed(evt);
            }
        });

        Btn_Eliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/interfaz_ii/quitar-usuario (1).png"))); // NOI18N
        Btn_Eliminar.setText("Eliminar");
        Btn_Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_EliminarActionPerformed(evt);
            }
        });

        Importar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/interfaz_ii/importar (1).png"))); // NOI18N
        Importar.setText("Importar");
        Importar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ImportarActionPerformed(evt);
            }
        });

        Exportar_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/interfaz_ii/exportar (1).png"))); // NOI18N
        Exportar_btn.setText("Exportar");
        Exportar_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Exportar_btnActionPerformed(evt);
            }
        });

        Btn_EliminarTabla.setText("Eli. DatBase");
        Btn_EliminarTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_EliminarTablaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout botonesLayout = new javax.swing.GroupLayout(botones);
        botones.setLayout(botonesLayout);
        botonesLayout.setHorizontalGroup(
            botonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(botonesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(botonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(botonesLayout.createSequentialGroup()
                        .addComponent(Btn_Agregar)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(botonesLayout.createSequentialGroup()
                        .addGroup(botonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(Btn_EliminarTabla, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Exportar_btn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Btn_Editar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Importar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Btn_Eliminar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        botonesLayout.setVerticalGroup(
            botonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(botonesLayout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(Btn_Agregar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Btn_Editar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Btn_Eliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Importar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Exportar_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addComponent(Btn_EliminarTabla)
                .addContainerGap())
        );

        jScrollPane1.setAutoscrolls(true);

        Tbl.setBackground(new java.awt.Color(0, 0, 0));
        Tbl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 255)));
        Tbl.setForeground(new java.awt.Color(0, 255, 153));
        Tbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        Tbl.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jScrollPane1.setViewportView(Tbl);

        titulo.setFont(new java.awt.Font("Segoe UI Historic", 0, 18)); // NOI18N
        titulo.setForeground(new java.awt.Color(0, 255, 153));
        titulo.setText("REGISTRO ESTUDIANTES");

        campo.setBackground(new java.awt.Color(0, 0, 28));
        campo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 102)));
        campo.setForeground(new java.awt.Color(0, 153, 51));

        txtCodigo.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCodigo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        txtCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodigoActionPerformed(evt);
            }
        });

        txtNombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtNombre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 255, 153));
        jLabel1.setText("Apellidos y Nombres:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 255, 51));
        jLabel3.setText("Codigo:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 255, 153));
        jLabel4.setText("2º Opcion:");

        cbxOpcion1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar", "Escuela profesional de Administración", "Escuela profesional de Contabilidad", "Escuela profesional de Economía", "Escuela profesional de Ingeniería Ambiental", "Escuela profesional de Ingeniería Civil", "Escuela profesional de Ingeniería en Ciberseguridad", "Escuela profesional de Ingeniería en Conservación de Suelos y Agua", "Escuela profesional de Ingeniería en Industrias Alimentarias", "Escuela profesional de Ingeniería en Informática y Sistemas", "Escuela profesional de Ingeniería en Recursos Naturales Renovables", "Escuela profesional de Ingeniería Forestal", "Escuela profesional de Ingeniería Mecánica Eléctrica", "Escuela profesional de Turismo y Hotelería", "Escuela profesional de Zootecnia", "Escuela profesional de Agronomía", " ", " ", " " }));
        cbxOpcion1.setOpaque(true);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 255, 153));
        jLabel5.setText("1º Opcion:");

        cbxOpcion2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar", "Escuela profesional de Administración", "Escuela profesional de Contabilidad", "Escuela profesional de Economía", "Escuela profesional de Ingeniería Ambiental", "Escuela profesional de Ingeniería Civil", "Escuela profesional de Ingeniería en Ciberseguridad", "Escuela profesional de Ingeniería en Conservación de Suelos y Agua", "Escuela profesional de Ingeniería en Industrias Alimentarias", "Escuela profesional de Ingeniería en Informática y Sistemas", "Escuela profesional de Ingeniería en Recursos Naturales Renovables", "Escuela profesional de Ingeniería Forestal", "Escuela profesional de Ingeniería Mecánica Eléctrica", "Escuela profesional de Turismo y Hotelería", "Escuela profesional de Zootecnia", "Escuela profesional de Agronomía", " ", " ", " " }));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 255, 153));
        jLabel8.setText("Modalidad:");

        cbxModalidad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecionar", "Víctima de terrorismo", "Arte y cultura", "Beca 18", "Modalidad ordinario", "Personas con discapacidad", "Centro Preuniversitario", "Exonerados primeros puestos", "Exonerados traslado interno", "Deportista calificado", "No definido" }));
        cbxModalidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxModalidadActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 255, 153));
        jLabel9.setText("DNI:");

        txtSede.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSede.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        txtSede.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSedeActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 255, 153));
        jLabel10.setText("Cod_Sede:");

        txtDNI.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtDNI.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        txtDNI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDNIActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 255, 153));
        jLabel11.setText("Fecha Egreso Colegio:");

        cbxTipoColegio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecionar", "Nacional", "Particular", "Parroquial", "Otro" }));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 255, 153));
        jLabel12.setText("Tipo Colegio:");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 255, 153));
        jLabel13.setText("Estado Civil:");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 255, 153));
        jLabel14.setText("Ubigeo Colegio:");

        txtUbiColegio.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtUbiColegio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        txtUbiColegio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUbiColegioActionPerformed(evt);
            }
        });

        txtIdioma.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtIdioma.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        txtIdioma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdiomaActionPerformed(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 255, 153));
        jLabel17.setText("Nombre de Colegio:");

        txtNomColegio.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtNomColegio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        txtNomColegio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomColegioActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 255, 255));

        txtTelefono.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTelefono.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        txtTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelefonoActionPerformed(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 255, 153));
        jLabel19.setText("Tel/Celular:");

        jLabel20.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 255, 153));
        jLabel20.setText("Direccion:");

        txtObservacion.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtObservacion.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        txtObservacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtObservacionActionPerformed(evt);
            }
        });

        jLabel21.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 255, 153));
        jLabel21.setText("Fecha Nacimiento:");

        cbxSecundaria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));

        jLabel22.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 255, 153));
        jLabel22.setText("Sexo:");

        cbxSexo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Femenino", "Masculino" }));

        jLabel23.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(0, 255, 153));
        jLabel23.setText("Idioma Nativo:");

        txtUbigeo.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtUbigeo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        txtUbigeo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUbigeoActionPerformed(evt);
            }
        });

        jLabel24.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(0, 255, 153));
        jLabel24.setText("Ubigeo:");

        jLabel25.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(0, 255, 153));
        jLabel25.setText("Observacio:");

        cbxEstadoCivil.setEditable(true);
        cbxEstadoCivil.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selccionar", "Soltero ", "Casado", "Viudo", "Divorciado" }));

        jLabel26.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(0, 255, 153));
        jLabel26.setText("Termino Secundaria:");

        txtDireccion.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtDireccion.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        txtDireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDireccionActionPerformed(evt);
            }
        });

        jLabel27.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(0, 255, 153));
        jLabel27.setText("Usuario:");

        txtUsuario.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtUsuario.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        txtUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUsuarioActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 255, 153));
        jLabel15.setText("Inscripcion:");

        jLabel16.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 255, 153));
        jLabel16.setText("Ubigeo Procedencia:");

        txtProcedencia.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtProcedencia.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        txtProcedencia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtProcedenciaActionPerformed(evt);
            }
        });

        jLabel28.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(0, 255, 153));
        jLabel28.setText("Cod Colegio:");

        txtCodColegio.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCodColegio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        txtCodColegio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodColegioActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout campoLayout = new javax.swing.GroupLayout(campo);
        campo.setLayout(campoLayout);
        campoLayout.setHorizontalGroup(
            campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(campoLayout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(campoLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addGroup(campoLayout.createSequentialGroup()
                                .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(campoLayout.createSequentialGroup()
                                        .addComponent(jLabel26)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cbxSecundaria, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel25)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtObservacion, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel27)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtUsuario))
                                    .addGroup(campoLayout.createSequentialGroup()
                                        .addComponent(jLabel19)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel20)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel24)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtUbigeo, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel21)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(dateNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(campoLayout.createSequentialGroup()
                                        .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addGroup(campoLayout.createSequentialGroup()
                                                    .addComponent(jLabel11)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(dateEgresoColegio, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(campoLayout.createSequentialGroup()
                                                    .addComponent(jLabel13)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                    .addComponent(cbxEstadoCivil, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jLabel22)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(cbxSexo, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jLabel17)))
                                            .addGroup(campoLayout.createSequentialGroup()
                                                .addComponent(jLabel28)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(txtCodColegio, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtNomColegio, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(campoLayout.createSequentialGroup()
                                                .addComponent(jLabel23)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(txtIdioma, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(campoLayout.createSequentialGroup()
                                                .addComponent(jLabel14)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(txtUbiColegio)))))
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel18)))
                        .addContainerGap(19, Short.MAX_VALUE))
                    .addGroup(campoLayout.createSequentialGroup()
                        .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(campoLayout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtNombre))
                            .addGroup(campoLayout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbxModalidad, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtDNI, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtSede, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(campoLayout.createSequentialGroup()
                                        .addComponent(jLabel12)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cbxTipoColegio, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(campoLayout.createSequentialGroup()
                                        .addComponent(jLabel15)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(dateInscripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(12, 12, 12)
                                        .addComponent(jLabel16)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtProcedencia))))
                            .addGroup(campoLayout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(cbxOpcion1, javax.swing.GroupLayout.PREFERRED_SIZE, 425, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cbxOpcion2, javax.swing.GroupLayout.PREFERRED_SIZE, 425, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18))))
        );
        campoLayout.setVerticalGroup(
            campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(campoLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbxOpcion1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbxOpcion2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cbxModalidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtSede, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtDNI, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtProcedencia, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(dateInscripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(campoLayout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(43, 43, 43))
                    .addGroup(campoLayout.createSequentialGroup()
                        .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dateEgresoColegio, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtUbiColegio, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtCodColegio, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(cbxTipoColegio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNomColegio, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbxSexo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtIdioma, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbxEstadoCivil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(campoLayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(campoLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(dateNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(txtUbigeo, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(campoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtObservacion, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbxSecundaria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        jButton1.setText("jButton1");

        javax.swing.GroupLayout Panel_PrincipalLayout = new javax.swing.GroupLayout(Panel_Principal);
        Panel_Principal.setLayout(Panel_PrincipalLayout);
        Panel_PrincipalLayout.setHorizontalGroup(
            Panel_PrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel_PrincipalLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(Panel_PrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(Panel_PrincipalLayout.createSequentialGroup()
                        .addGroup(Panel_PrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(botones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(Panel_PrincipalLayout.createSequentialGroup()
                                .addComponent(xd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 945, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(campo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(Panel_PrincipalLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(titulo)
                .addGap(440, 440, 440))
        );
        Panel_PrincipalLayout.setVerticalGroup(
            Panel_PrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel_PrincipalLayout.createSequentialGroup()
                .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(campo, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(Panel_PrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel_PrincipalLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addGap(12, 12, 12))
                    .addGroup(Panel_PrincipalLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(botones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addGroup(Panel_PrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_PrincipalLayout.createSequentialGroup()
                                .addComponent(xd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(40, 40, 40))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_PrincipalLayout.createSequentialGroup()
                                .addComponent(jButton1)
                                .addGap(30, 30, 30))))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Panel_Principal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Panel_Principal, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Btn_EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_EliminarActionPerformed
        int fila = Tbl.getSelectedRow();
        if (fila >= 0) {
            int confirmacion = JOptionPane.showConfirmDialog(null, "¿Está seguro de eliminar esta fila?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) {
                Tabla.removeRow(fila);
                JOptionPane.showMessageDialog(null, "Fila eliminada correctamente.");
                //     limpiarCampos();
            }
        } 
        else {
            JOptionPane.showMessageDialog(null, "Seleccione una fila para eliminar.");
        }
    }//GEN-LAST:event_Btn_EliminarActionPerformed

    private void Btn_EditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_EditarActionPerformed
        int fila = Tbl.getSelectedRow();
    if (fila >= 0) {
        DefaultTableModel modelo = (DefaultTableModel) Tbl.getModel();
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");

        txtCodigo.setText(valor(modelo, fila, 0));
        txtNombre.setText(valor(modelo, fila, 1));
        cbxOpcion1.setSelectedItem(valor(modelo, fila, 2));
        cbxOpcion2.setSelectedItem(valor(modelo, fila, 3));
        cbxModalidad.setSelectedItem(valor(modelo, fila, 4));
        txtDNI.setText(valor(modelo, fila, 5));
        txtSede.setText(valor(modelo, fila, 6));
        dateInscripcion.setDate(parsearFecha(valor(modelo, fila, 7), formato));
        txtProcedencia.setText(valor(modelo, fila, 8));
        txtCodColegio.setText(valor(modelo, fila, 9));
        dateEgresoColegio.setDate(parsearFecha(valor(modelo, fila, 10), formato));
        cbxTipoColegio.setSelectedItem(valor(modelo, fila, 11));
        txtUbiColegio.setText(valor(modelo, fila, 12));
        cbxEstadoCivil.setSelectedItem(valor(modelo, fila, 13));
        cbxSexo.setSelectedItem(valor(modelo, fila, 14));
        txtNomColegio.setText(valor(modelo, fila, 15));
        txtIdioma.setText(valor(modelo, fila, 16));
        txtTelefono.setText(valor(modelo, fila, 17));
        txtDireccion.setText(valor(modelo, fila, 18));
        txtUbigeo.setText(valor(modelo, fila, 19));
        dateNacimiento.setDate(parsearFecha(valor(modelo, fila, 20), formato));
        cbxSecundaria.setSelectedItem(valor(modelo, fila, 21));
        txtObservacion.setText(valor(modelo, fila, 22));
        txtUsuario.setText(valor(modelo, fila, 23));

        modelo.removeRow(fila); // permite volver a agregar la fila editada
        JOptionPane.showMessageDialog(null, "Edite los campos y presione 'Agregar' para actualizar.");
    } else {
        JOptionPane.showMessageDialog(null, "Seleccione una fila para editar.");
    }
    }//GEN-LAST:event_Btn_EditarActionPerformed
private String valor(DefaultTableModel modelo, int fila, int columna) {
    Object val = modelo.getValueAt(fila, columna);
    return val != null ? val.toString() : "";
}

private Date parsearFecha(String fechaStr, SimpleDateFormat formato) {
    try {
        return !fechaStr.isEmpty() ? formato.parse(fechaStr) : null;
    } catch (ParseException e) {
        return null;
    }
}

    private void Btn_AgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_AgregarActionPerformed

          if (txtCodigo.getText().trim().isEmpty() ||
        txtNombre.getText().trim().isEmpty() ||
        cbxOpcion1.getSelectedItem() == null ||
        cbxOpcion2.getSelectedItem() == null ||
        cbxModalidad.getSelectedItem() == null ||
        txtDNI.getText().trim().isEmpty() ||
        txtSede.getText().trim().isEmpty() ||
        dateInscripcion.getDate() == null ||
        txtProcedencia.getText().trim().isEmpty() ||
        txtCodColegio.getText().trim().isEmpty() ||
        dateEgresoColegio.getDate() == null ||
        cbxTipoColegio.getSelectedItem() == null ||
        txtUbiColegio.getText().trim().isEmpty() ||
        cbxEstadoCivil.getSelectedItem() == null ||
        cbxSexo.getSelectedItem() == null ||
        txtNomColegio.getText().trim().isEmpty() ||
        txtIdioma.getText().trim().isEmpty() ||
        txtTelefono.getText().trim().isEmpty() ||
        txtDireccion.getText().trim().isEmpty() ||
        txtUbigeo.getText().trim().isEmpty() ||
        dateNacimiento.getDate() == null ||
        cbxSecundaria.getSelectedItem() == null ||
        txtObservacion.getText().trim().isEmpty()) {

        JOptionPane.showMessageDialog(this, "Importar doc: Debes completar todos los campos.");
        return;
    }

    // Generar usuario si está vacío
    String usuarioGenerado = txtUsuario.getText().trim();
    if (usuarioGenerado.isEmpty()) {
        usuarioGenerado = "user" + txtDNI.getText().trim();
        txtUsuario.setText(usuarioGenerado);
    }

    // Obtener datos
    String codigo = txtCodigo.getText();
    String apellido = txtNombre.getText();
    String opcion1 = cbxOpcion1.getSelectedItem().toString();
    String opcion2 = cbxOpcion2.getSelectedItem().toString();
    String modalidad = cbxModalidad.getSelectedItem().toString();
    String dni = txtDNI.getText();
    String sede = txtSede.getText();
    String fechaInscripcion = new SimpleDateFormat("dd/MM/yyyy").format(dateInscripcion.getDate());
    String procedencia = txtProcedencia.getText();
    String codColegio = txtCodColegio.getText();
    String fechaEgreso = new SimpleDateFormat("dd/MM/yyyy").format(dateEgresoColegio.getDate());
    String tipoColegio = cbxTipoColegio.getSelectedItem().toString();
    String ubiColegio = txtUbiColegio.getText();
    String estadoCivil = cbxEstadoCivil.getSelectedItem().toString();
    String sexo = cbxSexo.getSelectedItem().toString();
    String nomColegio = txtNomColegio.getText();
    String idioma = txtIdioma.getText();
    String telefono = txtTelefono.getText();
    String direccion = txtDireccion.getText();
    String ubigeo = txtUbigeo.getText();
    String fechaNacimiento = new SimpleDateFormat("dd/MM/yyyy").format(dateNacimiento.getDate());
    String secundaria = cbxSecundaria.getSelectedItem().toString();
    String observacion = txtObservacion.getText();
    String usuario = usuarioGenerado;

    // Agregar a la tabla visual
    DefaultTableModel modelo = (DefaultTableModel) Tbl.getModel();
    modelo.addRow(new Object[]{
        codigo, apellido, opcion1, opcion2, modalidad, dni, sede, fechaInscripcion,
        procedencia, codColegio, fechaEgreso, tipoColegio, ubiColegio, estadoCivil,
        sexo, nomColegio, idioma, telefono, direccion, ubigeo, fechaNacimiento,
        secundaria, observacion, usuario
    });

    // Guardar en la base de datos H2
    try (Connection conn = DriverManager.getConnection("jdbc:h2:~/mi_base", "sa", "")) {
        // Verificar si la tabla existe
        try (Statement checkStmt = conn.createStatement()) {
            checkStmt.executeQuery("SELECT 1 FROM DATOS_IMPORTADOS LIMIT 1");
        }

        // Preparar y ejecutar INSERT
        String sql = "INSERT INTO DATOS_IMPORTADOS (codigo, apellido, opcion1, opcion2, modalidad, dni, sede, inscripcion, procedencia, cod_colegio, egreso, tipo_colegio, ubi_colegio, estado_civil, sexo, nom_colegio, idioma, telefono, direccion, ubigeo, nacimiento, secundaria, observacion, usuario) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, codigo);
        ps.setString(2, apellido);
        ps.setString(3, opcion1);
        ps.setString(4, opcion2);
        ps.setString(5, modalidad);
        ps.setString(6, dni);
        ps.setString(7, sede);
        ps.setString(8, fechaInscripcion);
        ps.setString(9, procedencia);
        ps.setString(10, codColegio);
        ps.setString(11, fechaEgreso);
        ps.setString(12, tipoColegio);
        ps.setString(13, ubiColegio);
        ps.setString(14, estadoCivil);
        ps.setString(15, sexo);
        ps.setString(16, nomColegio);
        ps.setString(17, idioma);
        ps.setString(18, telefono);
        ps.setString(19, direccion);
        ps.setString(20, ubigeo);
        ps.setString(21, fechaNacimiento);
        ps.setString(22, secundaria);
        ps.setString(23, observacion);
        ps.setString(24, usuario);
        ps.executeUpdate();
        ps.close();

        JOptionPane.showMessageDialog(this, "Registro guardado correctamente en la base de datos.");

    } catch (SQLException e) {/*
        JOptionPane.showMessageDialog(this,
            "Error al guardar en la base de datos.\n" +
            "¿Importaste el archivo Excel primero?\n\n" + e.getMessage(),
            "Error", JOptionPane.ERROR_MESSAGE);*/
    }

    // Limpiar campos
    txtCodigo.setText("");
    txtNombre.setText("");
    cbxOpcion1.setSelectedIndex(0);
    cbxOpcion2.setSelectedIndex(0);
    cbxModalidad.setSelectedIndex(0);
    txtDNI.setText("");
    txtSede.setText("");
    dateInscripcion.setDate(null);
    txtProcedencia.setText("");
    txtCodColegio.setText("");
    dateEgresoColegio.setDate(null);
    cbxTipoColegio.setSelectedIndex(0);
    txtUbiColegio.setText("");
    cbxEstadoCivil.setSelectedIndex(0);
    cbxSexo.setSelectedIndex(0);
    txtNomColegio.setText("");
    txtIdioma.setText("");
    txtTelefono.setText("");
    txtDireccion.setText("");
    txtUbigeo.setText("");
    dateNacimiento.setDate(null);
    cbxSecundaria.setSelectedIndex(0);
    txtObservacion.setText("");
    txtUsuario.setText("");
        
     /* Validar campos obligatorios
    if (txtCodigo.getText().trim().isEmpty() ||
        txtNombre.getText().trim().isEmpty() ||
        cbxOpcion1.getSelectedItem() == null ||
        cbxOpcion2.getSelectedItem() == null ||
        cbxModalidad.getSelectedItem() == null ||
        txtDNI.getText().trim().isEmpty() ||
        txtSede.getText().trim().isEmpty() ||
        dateInscripcion.getDate() == null ||
        txtProcedencia.getText().trim().isEmpty() ||
        txtCodColegio.getText().trim().isEmpty() ||
        dateEgresoColegio.getDate() == null ||
        cbxTipoColegio.getSelectedItem() == null ||
        txtUbiColegio.getText().trim().isEmpty() ||
        cbxEstadoCivil.getSelectedItem() == null ||
        cbxSexo.getSelectedItem() == null ||
        txtNomColegio.getText().trim().isEmpty() ||
        txtIdioma.getText().trim().isEmpty() ||
        txtTelefono.getText().trim().isEmpty() ||
        txtDireccion.getText().trim().isEmpty() ||
        txtUbigeo.getText().trim().isEmpty() ||
        dateNacimiento.getDate() == null ||
        cbxSecundaria.getSelectedItem() == null ||
        txtObservacion.getText().trim().isEmpty()) {
        
        JOptionPane.showMessageDialog(this, "Importar doc: Debes completar todos los campos.");
        return;
    }

    // Si no se ingresó usuario, crearlo automáticamente (por ejemplo, "user" + DNI)
    String usuarioGenerado = txtUsuario.getText().trim();
    if (usuarioGenerado.isEmpty()) {
        usuarioGenerado = "user" + txtDNI.getText().trim();
        txtUsuario.setText(usuarioGenerado);
    }

    // Obtener datos
    String codigo = txtCodigo.getText();
    String apellido = txtNombre.getText();
    String opcion1 = cbxOpcion1.getSelectedItem().toString();
    String opcion2 = cbxOpcion2.getSelectedItem().toString();
    String modalidad = cbxModalidad.getSelectedItem().toString();
    String dni = txtDNI.getText();
    String sede = txtSede.getText();
    String fechaInscripcion = new SimpleDateFormat("dd/MM/yyyy").format(dateInscripcion.getDate());
    String procedencia = txtProcedencia.getText();
    String codColegio = txtCodColegio.getText();
    String fechaEgreso = new SimpleDateFormat("dd/MM/yyyy").format(dateEgresoColegio.getDate());
    String tipoColegio = cbxTipoColegio.getSelectedItem().toString();
    String ubiColegio = txtUbiColegio.getText();
    String estadoCivil = cbxEstadoCivil.getSelectedItem().toString();
    String sexo = cbxSexo.getSelectedItem().toString();
    String nomColegio = txtNomColegio.getText();
    String idioma = txtIdioma.getText();
    String telefono = txtTelefono.getText();
    String direccion = txtDireccion.getText();
    String ubigeo = txtUbigeo.getText();
    String fechaNacimiento = new SimpleDateFormat("dd/MM/yyyy").format(dateNacimiento.getDate());
    String secundaria = cbxSecundaria.getSelectedItem().toString();
    String observacion = txtObservacion.getText();
    String usuario = usuarioGenerado;

    // Agregar fila a la tabla
    DefaultTableModel modelo = (DefaultTableModel) Tbl.getModel();
    modelo.addRow(new Object[]{
        codigo, apellido, opcion1, opcion2, modalidad, dni, sede, fechaInscripcion,
        procedencia, codColegio, fechaEgreso, tipoColegio, ubiColegio, estadoCivil,
        sexo, nomColegio, idioma, telefono, direccion, ubigeo, fechaNacimiento,
        secundaria, observacion, usuario
    });

    // Limpiar campos (opcional)
    txtCodigo.setText("");
    txtNombre.setText("");
    cbxOpcion1.setSelectedIndex(0);
    cbxOpcion2.setSelectedIndex(0);
    cbxModalidad.setSelectedIndex(0);
    txtDNI.setText("");
    txtSede.setText("");
    dateInscripcion.setDate(null);
    txtProcedencia.setText("");
    txtCodColegio.setText("");
    dateEgresoColegio.setDate(null);
    cbxTipoColegio.setSelectedIndex(0);
    txtUbiColegio.setText("");
    cbxEstadoCivil.setSelectedIndex(0);
    cbxSexo.setSelectedIndex(0);
    txtNomColegio.setText("");
    txtIdioma.setText("");
    txtTelefono.setText("");
    txtDireccion.setText("");
    txtUbigeo.setText("");
    dateNacimiento.setDate(null);
    cbxSecundaria.setSelectedIndex(0);
    txtObservacion.setText("");
    txtUsuario.setText("");
    }//GEN-LAST:event_Btn_AgregarActionPerformed

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
    }//GEN-LAST:event_txtNombreActionPerformed
    private void txtCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodigoActionPerformed
    }//GEN-LAST:event_txtCodigoActionPerformed
    private void Exportar_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Exportar_btnActionPerformed
     JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Guardar como");
    int seleccion = fileChooser.showSaveDialog(null);

    if (seleccion == JFileChooser.APPROVE_OPTION) {
        File archivo = fileChooser.getSelectedFile();

        // Verificar extensión
        String nombreArchivo = archivo.getAbsolutePath();
        boolean moderno = nombreArchivo.endsWith(".xlsx");

        if (!nombreArchivo.endsWith(".xls") && !moderno) {
            nombreArchivo += ".xlsx"; // por defecto .xlsx
            moderno = true;
        }

        try {
            Workbook libro;
            if (moderno) {
                libro = new XSSFWorkbook(); // Excel moderno (.xlsx)
            } else {
                libro = new HSSFWorkbook(); // Excel antiguo (.xls)
            }

            Sheet hoja = libro.createSheet("Datos");
            DefaultTableModel modelo = (DefaultTableModel) Tbl.getModel();

            // Escribir encabezados
            Row filaEncabezado = hoja.createRow(0);
            for (int i = 0; i < modelo.getColumnCount(); i++) {
                Cell celda = filaEncabezado.createCell(i);
                celda.setCellValue(modelo.getColumnName(i));
            }

            // Escribir filas de datos
            for (int i = 0; i < modelo.getRowCount(); i++) {
                Row filaDatos = hoja.createRow(i + 1);
                for (int j = 0; j < modelo.getColumnCount(); j++) {
                    Cell celda = filaDatos.createCell(j);
                    Object valor = modelo.getValueAt(i, j);
                    celda.setCellValue(valor != null ? valor.toString() : "");
                }
            }

            // Guardar archivo
            try (FileOutputStream archivoSalida = new FileOutputStream(nombreArchivo)) {
                libro.write(archivoSalida);
            }

            JOptionPane.showMessageDialog(null, "Datos exportados a Excel correctamente.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al exportar: " + e.getMessage());
        }
    }*/
    }//GEN-LAST:event_Exportar_btnActionPerformed

    private void ImportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ImportarActionPerformed

   JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Seleccionar archivo Excel");
    int seleccion = fileChooser.showOpenDialog(this);

    if (seleccion == JFileChooser.APPROVE_OPTION) {
        File archivo = fileChooser.getSelectedFile();
        String nombreArchivo = archivo.getName().toLowerCase();

        if (!nombreArchivo.endsWith(".xls") && !nombreArchivo.endsWith(".xlsx")) {
            JOptionPane.showMessageDialog(this, "Selecciona un archivo .xls o .xlsx válido.");
            return;
        }

        // Mapa: nombre visible → nombre limpio
        Map<String, String> columnasLimpias = new LinkedHashMap<>();

        try (FileInputStream fis = new FileInputStream(archivo)) {
            Workbook libro;
            if (nombreArchivo.endsWith(".xls")) {
                libro = new HSSFWorkbook(fis); // Excel antiguo
            } else {
                libro = new XSSFWorkbook(fis); // Excel moderno
            }

            Sheet hoja = libro.getSheetAt(0);
            DefaultTableModel modelo = (DefaultTableModel) Tbl.getModel();
            modelo.setRowCount(0);
            modelo.setColumnCount(0);

            Row encabezado = hoja.getRow(0);
            if (encabezado == null) {
                JOptionPane.showMessageDialog(this, "El archivo no tiene encabezado.");
                return;
            }

            // Crear columnas en JTable y mapa de nombres limpios
            for (int i = 0; i < encabezado.getLastCellNum(); i++) {
                Cell celda = encabezado.getCell(i);
                String nombreCol = (celda != null) ? celda.toString().trim() : "Columna_" + (i + 1);
                modelo.addColumn(nombreCol); // Se muestra como está en el Excel
                // Limpiar nombre para SQL: quitar símbolos raros, espacios, etc.
                String limpio = nombreCol.replaceAll("[^a-zA-Z0-9]", "_");
                columnasLimpias.put(nombreCol, limpio);
            }

            // Leer y agregar filas
            for (int i = 1; i <= hoja.getLastRowNum(); i++) {
                Row fila = hoja.getRow(i);
                if (fila == null) continue;

                Object[] datosFila = new Object[encabezado.getLastCellNum()];
                for (int j = 0; j < encabezado.getLastCellNum(); j++) {
                    Cell celda = fila.getCell(j);
                    if (celda == null) {
                        datosFila[j] = "";
                    } else {
                        switch (celda.getCellType()) {
                            case STRING -> datosFila[j] = celda.getStringCellValue();
                            case NUMERIC -> datosFila[j] = DateUtil.isCellDateFormatted(celda)
                                    ? celda.getDateCellValue()
                                    : celda.getNumericCellValue();
                            case BOOLEAN -> datosFila[j] = celda.getBooleanCellValue();
                            case FORMULA -> datosFila[j] = celda.getCellFormula();
                            case BLANK -> datosFila[j] = "";
                            default -> datosFila[j] = celda.toString();
                        }
                    }
                }
                modelo.addRow(datosFila);
            }

            JOptionPane.showMessageDialog(this, "Archivo importado exitosamente.");

            // 🔽 INSERTAR EN H2
            try (Connection conn = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "")) {
                int columnas = modelo.getColumnCount();

                // Crear tabla H2 con columnas limpias
                StringBuilder sqlCreate = new StringBuilder("CREATE TABLE IF NOT EXISTS datos_importados (");
                int i = 0;
                for (String nombreOriginal : columnasLimpias.keySet()) {
                    sqlCreate.append(columnasLimpias.get(nombreOriginal)).append(" VARCHAR(255)");
                    if (i++ < columnasLimpias.size() - 1) sqlCreate.append(", ");
                }
                sqlCreate.append(")");
                conn.createStatement().execute(sqlCreate.toString());

                // Preparar insert
                StringBuilder sqlInsert = new StringBuilder("INSERT INTO datos_importados VALUES (");
                sqlInsert.append("?,".repeat(columnas - 1)).append("?");
                sqlInsert.append(")");

                for (int fila = 0; fila < modelo.getRowCount(); fila++) {
                    try (PreparedStatement stmt = conn.prepareStatement(sqlInsert.toString())) {
                        for (int col = 0; col < columnas; col++) {
                            Object valor = modelo.getValueAt(fila, col);
                            stmt.setString(col + 1, valor != null ? valor.toString() : "");
                        }
                        stmt.executeUpdate();
                    }
                }

                JOptionPane.showMessageDialog(this, "Datos insertados en H2 correctamente.");
                    
                 Statement stmt = conn.createStatement();
    ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM datos_importados");
    if (rs.next()) {
        int total = rs.getInt(1);
        System.out.println("✅ Filas insertadas: " + total);
        JOptionPane.showMessageDialog(this, "Filas insertadas en H2: " + total);
    }
                ResultSet tablas = conn.getMetaData().getTables(null, null, "%", new String[]{"TABLE"});
System.out.println("Tablas encontradas en la base de datos:");
while (tablas.next()) {
    System.out.println("📦 " + tablas.getString("TABLE_NAME"));
}
                
                
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error al insertar en H2: " + ex.getMessage());
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al importar: " + e.getMessage());
        }
    }

    }//GEN-LAST:event_ImportarActionPerformed

    private void txtSedeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSedeActionPerformed
    }//GEN-LAST:event_txtSedeActionPerformed
    private void txtDNIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDNIActionPerformed
    }//GEN-LAST:event_txtDNIActionPerformed
    private void txtUbiColegioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUbiColegioActionPerformed
    }//GEN-LAST:event_txtUbiColegioActionPerformed
    private void txtIdiomaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdiomaActionPerformed
    }//GEN-LAST:event_txtIdiomaActionPerformed
    private void txtNomColegioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomColegioActionPerformed
    }//GEN-LAST:event_txtNomColegioActionPerformed
    private void txtTelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelefonoActionPerformed
    }//GEN-LAST:event_txtTelefonoActionPerformed
    private void txtObservacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtObservacionActionPerformed
    }//GEN-LAST:event_txtObservacionActionPerformed
    private void txtUbigeoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUbigeoActionPerformed
    }//GEN-LAST:event_txtUbigeoActionPerformed
    private void txtDireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDireccionActionPerformed
    }//GEN-LAST:event_txtDireccionActionPerformed
    private void txtUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsuarioActionPerformed
    }//GEN-LAST:event_txtUsuarioActionPerformed
    private void cbxModalidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxModalidadActionPerformed
    }//GEN-LAST:event_cbxModalidadActionPerformed
    private void txtProcedenciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtProcedenciaActionPerformed
    }//GEN-LAST:event_txtProcedenciaActionPerformed
    private void txtCodColegioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodColegioActionPerformed
    }//GEN-LAST:event_txtCodColegioActionPerformed

    private JDesktopPane contenedor; // referencia al contenedor

// Constructor que recibe el contenedor
    public Registro_Alum(JDesktopPane contenedor) {
    initComponents();
        this.contenedor = contenedor;
    setClosable(true);
    setIconifiable(true);
    setMaximizable(true);
    setResizable(false);
    setFocusable(true); // 👈 Asegúrate de esto

    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    
}
    
    
    private void Btn_EliminarTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_EliminarTablaActionPerformed
          int confirmacion = JOptionPane.showConfirmDialog(this,
        "¿Estás seguro de eliminar la tabla 'datos_importados'?\nSe perderán todos los datos.",
        "Confirmar eliminación",
        JOptionPane.YES_NO_OPTION);

    if (confirmacion == JOptionPane.YES_OPTION) {
        try (Connection conn = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "")) {
            Statement stmt = conn.createStatement();
            stmt.execute("DROP TABLE IF EXISTS datos_importados");
            JOptionPane.showMessageDialog(this, "✅ Tabla 'datos_importados' eliminada correctamente.");

            // Limpia la JTable si quieres también
            DefaultTableModel modelo = (DefaultTableModel) Tbl.getModel();
            modelo.setRowCount(0);
            modelo.setColumnCount(0);

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "❌ Error al eliminar la tabla: " + ex.getMessage());
        }
    }
        
        
        

        
    }//GEN-LAST:event_Btn_EliminarTablaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btn_Agregar;
    private javax.swing.JButton Btn_Editar;
    private javax.swing.JButton Btn_Eliminar;
    private javax.swing.JButton Btn_EliminarTabla;
    private javax.swing.JButton Exportar_btn;
    private javax.swing.JButton Importar;
    private javax.swing.JPanel Panel_Principal;
    private javax.swing.JTable Tbl;
    private javax.swing.JPanel botones;
    private javax.swing.JPanel campo;
    private javax.swing.JComboBox<String> cbxEstadoCivil;
    private javax.swing.JComboBox<String> cbxModalidad;
    private javax.swing.JComboBox<String> cbxOpcion1;
    private javax.swing.JComboBox<String> cbxOpcion2;
    private javax.swing.JComboBox<String> cbxSecundaria;
    private javax.swing.JComboBox<String> cbxSexo;
    private javax.swing.JComboBox<String> cbxTipoColegio;
    private com.toedter.calendar.JDateChooser dateEgresoColegio;
    private com.toedter.calendar.JDateChooser dateInscripcion;
    private com.toedter.calendar.JDateChooser dateNacimiento;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel titulo;
    private javax.swing.JTextField txtCodColegio;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextField txtDNI;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtIdioma;
    private javax.swing.JTextField txtNomColegio;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtObservacion;
    private javax.swing.JTextField txtProcedencia;
    private javax.swing.JTextField txtSede;
    private javax.swing.JTextField txtTelefono;
    private javax.swing.JTextField txtUbiColegio;
    private javax.swing.JTextField txtUbigeo;
    private javax.swing.JTextField txtUsuario;
    private javax.swing.JComboBox<String> xd;
    // End of variables declaration//GEN-END:variables
}
