/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package interfaz_ii ;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;


import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;

import org.apache.poi.xssf.usermodel.XSSFWorkbook; 

// Para PDF con OpenPDF
import com.lowagie.text.Document;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfWriter;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LinearGradientPaint;
import java.awt.geom.Point2D;
import java.beans.PropertyVetoException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDesktopPane;

import javax.swing.JPanel;



public class ReporteVisualAulas extends javax.swing.JInternalFrame {
// Mapa de pabellón → lista de números de aulas
private Map<String, List<String>> aulasPorPabellon = new HashMap<>();

// Mapa de aula (código completo) → lista de alumnos
private Map<String, List<String>> alumnosPorAula = new HashMap<>();

// Mapa de aula → docente asignado
private Map<String, String> docentePorAula = new HashMap<>();
    
    
          public ReporteVisualAulas() {
        initComponents();
          this.contenedor = contenedor;
        setClosable(true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
     
        
cbxpabellon.addActionListener(evt -> {
    cbxaulas.removeAllItems();
    String pab = (String) cbxpabellon.getSelectedItem();
    if (pab != null) {
        for (String num : aulasPorPabellon.get(pab)) {
            cbxaulas.addItem(pab + "-" + num);
        }
    }
    if (cbxaulas.getItemCount() > 0) {
        cbxaulas.setSelectedIndex(0);
    }
});  

cbxaulas.addActionListener(evt -> {
    String aulaSeleccionada = (String) cbxaulas.getSelectedItem();
    if (aulaSeleccionada == null) return;

    List<String> alumnos = alumnosPorAula.getOrDefault(aulaSeleccionada, new ArrayList<>());
    String docente = docentePorAula.getOrDefault(aulaSeleccionada, "No asignado");

    String[][] datos = new String[alumnos.size()][3];
    for (int i = 0; i < alumnos.size(); i++) {
        datos[i][0] = String.valueOf(i + 1);
        datos[i][1] = alumnos.get(i);
        datos[i][2] = docente;
    }

    tablaVisual.setModel(new javax.swing.table.DefaultTableModel(
        datos,
        new String[] { "Asiento", "Alumno", "Docente a Cargo" }
    ));
});


}

    class jPanelGradient extends JPanel {
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
    Graphics2D g2d = (Graphics2D) g;
    int width = getWidth();
    int height = getHeight();

    // Puntos de inicio y fin del degradado (vertical)
    Point2D start = new Point2D.Float(0, 0);
    Point2D end = new Point2D.Float(0, height);

    // Tres colores: gris claro arriba, verde medio, gris claro abajo
    Color[] colores = {
        new Color(0, 0, 0),   // Gris claro (arriba)
        new Color(4, 143, 57),      // Verde (centro)
        new Color(0, 0, 0)    // Gris claro (abajo)
    };

    // Posiciones relativas: 0.0 = inicio, 1.0 = fin
    float[] posiciones = { 0.0f, 0.5f, 1.0f };

    // Crear y aplicar el degradado lineal
    LinearGradientPaint lgp = new LinearGradientPaint(start, end, posiciones, colores);
    g2d.setPaint(lgp);
    g2d.fillRect(0, 0, width, height);
        }
}   
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new jPanelGradient();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cbxpabellon = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        cbxaulas = new javax.swing.JComboBox<>();
        btncargardatos = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaVisual = new javax.swing.JTable();
        btnexportar = new javax.swing.JButton();

        setClosable(true);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 255, 153));
        jLabel1.setText("REPORTE VISUAL DE AULAS ");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 255, 153));
        jLabel2.setText("Seleccione el Pabellon: ");

        cbxpabellon.setForeground(new java.awt.Color(0, 255, 153));
        cbxpabellon.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 255, 153));
        jLabel3.setText("Seleccione el Salon:");

        cbxaulas.setForeground(new java.awt.Color(0, 255, 153));
        cbxaulas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btncargardatos.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btncargardatos.setText("Cargar Datos");
        btncargardatos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        btncargardatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncargardatosActionPerformed(evt);
            }
        });

        tablaVisual.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        tablaVisual.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Asiento", "Alumno", "Docente a Cargo"
            }
        ));
        jScrollPane1.setViewportView(tablaVisual);
        if (tablaVisual.getColumnModel().getColumnCount() > 0) {
            tablaVisual.getColumnModel().getColumn(0).setPreferredWidth(6);
            tablaVisual.getColumnModel().getColumn(1).setPreferredWidth(170);
            tablaVisual.getColumnModel().getColumn(2).setPreferredWidth(120);
        }

        btnexportar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnexportar.setText("Exportar Excel y PDF");
        btnexportar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        btnexportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnexportarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel3)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cbxpabellon, 0, 132, Short.MAX_VALUE)
                    .addComponent(cbxaulas, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(59, 59, 59)
                .addComponent(btncargardatos, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(261, 261, 261))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(132, 132, 132)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(95, 95, 95)
                        .addComponent(btnexportar))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 674, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1)
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cbxpabellon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(cbxaulas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(btncargardatos, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 106, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(87, 87, 87)
                .addComponent(btnexportar)
                .addGap(75, 75, 75))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 687, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private void procesarArchivoAulas(File archivo) {
   
     try (FileInputStream fis = new FileInputStream(archivo);
         Workbook libro = WorkbookFactory.create(fis)) {

        Sheet hoja = libro.getSheetAt(0);
        DataFormatter formatter = new DataFormatter(); // Para leer números como texto

        aulasPorPabellon.clear(); // importante: limpiar antes

        for (Row fila : hoja) {
            if (fila.getRowNum() == 0) continue;

            String pabellon = formatter.formatCellValue(fila.getCell(0));
            String numeroAula = formatter.formatCellValue(fila.getCell(1));

            if (!aulasPorPabellon.containsKey(pabellon)) {
                aulasPorPabellon.put(pabellon, new ArrayList<>());
            }
            aulasPorPabellon.get(pabellon).add(numeroAula);
        }

        // Actualizar combo
        cbxpabellon.removeAllItems();
        for (String pab : aulasPorPabellon.keySet()) {
            cbxpabellon.addItem(pab);
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al procesar el archivo de aulas.");
        e.printStackTrace();
    }
     if (cbxpabellon.getItemCount() > 0) {
    cbxpabellon.setSelectedIndex(0); // dispara la previsualización de la primera aula
}
  cbxpabellon.setSelectedIndex(0);      
}
    
private void procesarArchivoAlumnos(File archivo) {
    try (FileInputStream fis = new FileInputStream(archivo);
         Workbook libro = WorkbookFactory.create(fis)) {

        DataFormatter fmt = new DataFormatter();
        Sheet hoja = libro.getSheetAt(0);

        // limpiar antes
        alumnosPorAula.clear();

        for (Row fila : hoja) {
            if (fila.getRowNum() == 0) continue;
            String codAula = fmt.formatCellValue(fila.getCell(0)).trim();
            String alumno = fmt.formatCellValue(fila.getCell(1)).trim();
            if (codAula.isEmpty() || alumno.isEmpty()) continue;

            alumnosPorAula.computeIfAbsent(codAula, k -> new ArrayList<>()).add(alumno);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al leer el archivo de alumnos.");
        e.printStackTrace();
    }
    
}

private void procesarArchivoDocentes(File archivo) {
    try (FileInputStream fis = new FileInputStream(archivo);
         Workbook libro = WorkbookFactory.create(fis)) {

        DataFormatter fmt = new DataFormatter();
        Sheet hoja = libro.getSheetAt(0);

        // limpiar antes
        docentePorAula.clear();

        for (Row fila : hoja) {
            if (fila.getRowNum() == 0) continue;
            String codAula = fmt.formatCellValue(fila.getCell(0)).trim();
            String docente = fmt.formatCellValue(fila.getCell(1)).trim();
            if (codAula.isEmpty() || docente.isEmpty()) continue;

            docentePorAula.put(codAula, docente);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al leer el archivo de docentes.");
        e.printStackTrace();
    }

}


    
    private void btncargardatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncargardatosActionPerformed
     aulasPorPabellon.clear();
     alumnosPorAula.clear();
     docentePorAula.clear();
    JFileChooser fileChooser = new JFileChooser();

    // Selección archivo de aulas
    JOptionPane.showMessageDialog(this, "Selecciona el archivo de AULAS");
    if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
        procesarArchivoAulas(fileChooser.getSelectedFile());
    }

    // Selección archivo de alumnos
    JOptionPane.showMessageDialog(this, "Selecciona el archivo de ALUMNOS");
    if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
        procesarArchivoAlumnos(fileChooser.getSelectedFile());
    }

    // Selección archivo de docentes
    JOptionPane.showMessageDialog(this, "Selecciona el archivo de DOCENTES");
    if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
        procesarArchivoDocentes(fileChooser.getSelectedFile());
    }
    
    if (cbxpabellon.getItemCount() > 0) {
    cbxpabellon.setSelectedIndex(0); // esto disparará el listener y llenará cbxaulas y tabla
}
    
    }//GEN-LAST:event_btncargardatosActionPerformed

    private void btnexportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnexportarActionPerformed
        
 // 1. Obtener nombre del aula seleccionada
    String aulaSeleccionada = cbxaulas.getSelectedItem().toString().trim();
    String nombreArchivoBase = "Reporte_" + aulaSeleccionada.replaceAll("\\s+", "_");

    // 2. Crear FileChooser con nombre sugerido
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Guardar reporte como...");
    fileChooser.setSelectedFile(new File(nombreArchivoBase + ".xlsx"));
    fileChooser.setFileFilter(new FileNameExtensionFilter("Excel (.xlsx)", "xlsx"));

    if (fileChooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
        return; // El usuario canceló
    }

    File excelFile = fileChooser.getSelectedFile();
    // Asegurarse que tenga extensión .xlsx
    if (!excelFile.getName().toLowerCase().endsWith(".xlsx")) {
        excelFile = new File(excelFile.getParentFile(), excelFile.getName() + ".xlsx");
    }

    // Construir ruta del PDF en la misma carpeta
    String baseName = excelFile.getAbsolutePath().substring(0,
        excelFile.getAbsolutePath().lastIndexOf('.'));
    File pdfFile = new File(baseName + ".pdf");

    TableModel model = tablaVisual.getModel();

    // --- 1) Exportar a Excel ---
    try (Workbook wb = new XSSFWorkbook();
         FileOutputStream fos = new FileOutputStream(excelFile)) {

        Sheet sheet = wb.createSheet("Reporte");
        // Encabezados
        Row header = sheet.createRow(0);
        for (int col = 0; col < model.getColumnCount(); col++) {
            Cell cell = header.createCell(col);
            cell.setCellValue(model.getColumnName(col));
        }
        // Filas de datos
        for (int row = 0; row < model.getRowCount(); row++) {
            Row excelRow = sheet.createRow(row + 1);
            for (int col = 0; col < model.getColumnCount(); col++) {
                Object value = model.getValueAt(row, col);
                Cell cell = excelRow.createCell(col);
                if (value != null) {
                    cell.setCellValue(value.toString());
                }
            }
        }
        // Auto-ajustar columnas
        for (int col = 0; col < model.getColumnCount(); col++) {
            sheet.autoSizeColumn(col);
        }
        wb.write(fos);

    } catch (Exception ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this,
            "Error al exportar Excel:\n" + ex.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
        return;
    }

    // --- 2) Exportar a PDF ---
    try (FileOutputStream pdfFos = new FileOutputStream(pdfFile)) {
        Document document = new Document();
        PdfWriter.getInstance(document, pdfFos);
        document.open();
        // Título
       document.add(new Paragraph("                           Reporte Visual del Aula"));
       
// Obtener docente a cargo del Map (si no hay, mostrar “No asignado”)
 String docente = docentePorAula.getOrDefault(aulaSeleccionada, "No asignado");

// Crear una línea con aula y docente alineados
document.add(new Paragraph("AULA: " + aulaSeleccionada + "                                                        Docente a Cargo: " + docente));
document.add(new Paragraph(" ")); // Línea en blanco

       // --- Tabla PDF sin la columna "Docente" ---
int columnaDocente = -1;
for (int i = 0; i < model.getColumnCount(); i++) {
    String nombreCol = model.getColumnName(i).trim().toLowerCase();
    if (nombreCol.contains("docente")) {
        columnaDocente = i;
        break;
    }
}


int columnasPDF = (columnaDocente == -1) ? model.getColumnCount() : model.getColumnCount() - 1;

PdfPTable pdfTable = new PdfPTable(columnasPDF);

// Encabezados (sin "Docente")
for (int col = 0; col < model.getColumnCount(); col++) {
    if (col == columnaDocente) continue;
    PdfPCell cell = new PdfPCell(new Paragraph(model.getColumnName(col)));
    pdfTable.addCell(cell);
}

// Filas de datos (sin "Docente")
for (int row = 0; row < model.getRowCount(); row++) {
    for (int col = 0; col < model.getColumnCount(); col++) {
        if (col == columnaDocente) continue;
        Object value = model.getValueAt(row, col);
        PdfPCell cell = new PdfPCell(new Paragraph(value != null ? value.toString() : ""));
        pdfTable.addCell(cell);
    }
}

document.add(pdfTable);
document.close();

    } catch (Exception ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this,
            "Error al exportar PDF:\n" + ex.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
        return;
    }

    // --- 3) Mensaje de éxito ---
    JOptionPane.showMessageDialog(this,
        "<html>Archivos generados exitosamente:<br/>" +
        "- Excel: " + excelFile.getAbsolutePath() + "<br/>" +
        "- PDF: " + pdfFile.getAbsolutePath() +
        "</html>",
        "Exportado",
        JOptionPane.INFORMATION_MESSAGE);
        
    }//GEN-LAST:event_btnexportarActionPerformed

    
    
    private JDesktopPane contenedor;
    
    public ReporteVisualAulas(JDesktopPane contenedor) {
    initComponents();
        this.contenedor = contenedor;
    
}
    private File seleccionarArchivo(String titulo) {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle(titulo);
    fileChooser.setFileFilter(new FileNameExtensionFilter("Archivos Excel", "xlsx", "xls"));

    int seleccion = fileChooser.showOpenDialog(this);
    if (seleccion == JFileChooser.APPROVE_OPTION) {
        return fileChooser.getSelectedFile();
    }
    return null;
}

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReporteVisualAulas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReporteVisualAulas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReporteVisualAulas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReporteVisualAulas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReporteVisualAulas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btncargardatos;
    private javax.swing.JButton btnexportar;
    private javax.swing.JComboBox<String> cbxaulas;
    private javax.swing.JComboBox<String> cbxpabellon;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaVisual;
    // End of variables declaration//GEN-END:variables
}
