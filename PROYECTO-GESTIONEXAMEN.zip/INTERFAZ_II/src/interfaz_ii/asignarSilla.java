/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
/*package interfaz_ii;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LinearGradientPaint;
import java.awt.geom.Point2D;
import java.io.File;
import java.util.List;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import javax.swing.JDesktopPane;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author NOEMI
 
class Aula {
    String nombre;
    List<Integer> sillas;
    Map<String, Integer> colegioCount = new HashMap<>();
    Map<String, List<Integer>> apellidoSillas = new HashMap<>();
    Map<String, List<Integer>> colegioSillas = new HashMap<>(); // Nuevo

    public Aula(String nombre, int cantidadSillas) {
        this.nombre = nombre;
        this.sillas = new ArrayList<>();
        for (int i = 1; i <= cantidadSillas; i++) {
            sillas.add(i);
        }
        Collections.shuffle(sillas);
    }

    public boolean puedeAsignar(String colegio, String apellido) {
        int countColegio = colegioCount.getOrDefault(colegio, 0);
        int countApellido = apellidoSillas.getOrDefault(apellido, new ArrayList<>()).size();

        if (countColegio >= 3 || countApellido >= 4) return false;

        for (int silla : sillas) {
            boolean lejanoApellido = apellidoSillas.getOrDefault(apellido, new ArrayList<>())
                .stream().allMatch(s -> Math.abs(s - silla) >= 3);
            boolean lejanoColegio = colegioSillas.getOrDefault(colegio, new ArrayList<>())
                .stream().allMatch(s -> Math.abs(s - silla) >= 3);
            if (lejanoApellido && lejanoColegio) return true;
        }
        return false;
    }

    public int asignarSilla(String colegio, String apellido) {
        for (int i = 0; i < sillas.size(); i++) {
            int silla = sillas.get(i);
            boolean lejanoApellido = apellidoSillas.getOrDefault(apellido, new ArrayList<>())
                .stream().allMatch(s -> Math.abs(s - silla) >= 3);
            boolean lejanoColegio = colegioSillas.getOrDefault(colegio, new ArrayList<>())
                .stream().allMatch(s -> Math.abs(s - silla) >= 3);

            if (lejanoApellido && lejanoColegio) {
                sillas.remove(i);
                colegioCount.put(colegio, colegioCount.getOrDefault(colegio, 0) + 1);
                apellidoSillas.computeIfAbsent(apellido, k -> new ArrayList<>()).add(silla);
                colegioSillas.computeIfAbsent(colegio, k -> new ArrayList<>()).add(silla); // Registrar
                return silla;
            }
        }
        return -1; // No encontró silla válida
        
    }

}

public class asignarSilla extends javax.swing.JInternalFrame {
private List<Aula> aulasCargadas = new ArrayList<>();
private List<String[]> estudiantes = new ArrayList<>();
private DefaultTableModel modelo;
private void cargarAulasDesdeExcel() {
    try {
        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            Workbook workbook;
            if (archivo.getName().endsWith(".xls")) {
                workbook = new HSSFWorkbook(new FileInputStream(archivo));
            } else if (archivo.getName().endsWith(".xlsx")) {
                workbook = new XSSFWorkbook(new FileInputStream(archivo));
            } else {
                JOptionPane.showMessageDialog(this, "Archivo no válido.");
                return;
            }

            Sheet hoja = workbook.getSheetAt(0);
            aulasCargadas.clear(); 

            for (int i = 1; i <= hoja.getLastRowNum(); i++) {
                Row fila = hoja.getRow(i);
                if (fila == null) continue;
                Cell celdaNombre = fila.getCell(0);
                Cell celdaCapacidad = fila.getCell(1);
                if (celdaNombre == null || celdaCapacidad == null) continue;
                String nombreAula = celdaNombre.toString().trim();
                int capacidad = 0;

                // Manejar diferentes tipos de celda para capacidad
                switch (celdaCapacidad.getCellType()) {
                    case NUMERIC:
                    capacidad = (int) celdaCapacidad.getNumericCellValue();
                    break;
                    case STRING:
                    try {
                        capacidad = Integer.parseInt(celdaCapacidad.getStringCellValue().trim());
                    }
                    catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(this, "Error: Capacidad no válida en la fila " + (i + 1));
                        continue;
                    }
                    break;
                    default:
                    JOptionPane.showMessageDialog(this, "Tipo de dato no válido para capacidad en la fila " + (i + 1));
                    continue;
                }
                aulasCargadas.add(new Aula(nombreAula, capacidad));
            }

                workbook.close();
                JOptionPane.showMessageDialog(this, "Aulas cargadas correctamente.");
        }
    } 
    catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al cargar aulas: " + e.getMessage());
        e.printStackTrace();
    }
}

private void cargarArchivoExcel() {
   try {
        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File archivoSeleccionado = fileChooser.getSelectedFile();
            Workbook workbook;

            if (archivoSeleccionado.getName().endsWith(".xls")) {
                workbook = new HSSFWorkbook(new FileInputStream(archivoSeleccionado));
            } else if (archivoSeleccionado.getName().endsWith(".xlsx")) {
                workbook = new XSSFWorkbook(new FileInputStream(archivoSeleccionado));
            } else {
                throw new IllegalArgumentException("El archivo no es un formato de Excel válido.");
            }

            Sheet sheet = workbook.getSheetAt(0);
            modelo = new DefaultTableModel();
            String[] encabezadosTabla = {"Código", "Nombres", "DNI", "Carrera", "Colegio", "ubigeo colegio", "Aula", "Silla"};
            modelo.setColumnIdentifiers(encabezadosTabla);

            String[] columnasExcel = {"CODIGO", "Apellidos y Nombres", "DNI", "OPCION 1", "NOMBRE COLEGIO", "UBIGEO COLEGIO"};
            Row filaEncabezado = sheet.getRow(0);
            Map<String, Integer> indices = new HashMap<>();

            for (int i = 0; i < filaEncabezado.getLastCellNum(); i++) {
                String nombre = filaEncabezado.getCell(i).toString().trim();
                for (String col : columnasExcel) {
                    if (nombre.equalsIgnoreCase(col)) {
                        indices.put(col, i);
                    }
                }
            }

            for (String col : columnasExcel) {
                if (!indices.containsKey(col)) {
                    throw new Exception("Columna faltante: " + col);
                }
            }

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row fila = sheet.getRow(i);
                if (fila == null) continue;

                String[] datos = new String[columnasExcel.length];
                for (int j = 0; j < columnasExcel.length; j++) {
                    int colIndex = indices.get(columnasExcel[j]);
                    Cell celda = fila.getCell(colIndex);
                    if (celda != null) {
                        switch (celda.getCellType()) {
                            case STRING:
                                datos[j] = celda.getStringCellValue();
                                break;
                            case NUMERIC:
                                datos[j] = String.valueOf((long) celda.getNumericCellValue());
                                break;
                            default:
                                datos[j] = celda.toString();
                        }
                    } else {
                        datos[j] = "";
                    }
                }

                // Añadir fila a la tabla
                modelo.addRow(new Object[]{
                    datos[0], datos[1], datos[2], datos[3], datos[4], datos[5], "", ""
                });

                estudiantes.add(new String[]{datos[1], datos[0], datos[4]});
            }

            jTable1.setModel(modelo);
            workbook.close();
            JOptionPane.showMessageDialog(this, "Archivo cargado correctamente.");
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al leer el archivo: " + e.getMessage());
        e.printStackTrace();
    } 
}

    /**
     * reates new form asignarSilla
     
    public asignarSilla() {
        initComponents();
        setClosable(true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE); // ← esto es clave
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);

        jButton1.setText("CARGAR ARCHIVO");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cargarArchivoExcel();
            }
        });

        jButton4.setText("CARGAR AULAS Y SILLAS");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cargarAulasDesdeExcel();
            }
        });

    }
    
    class jPanelGradient extends JPanel {
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
    Graphics2D g2d = (Graphics2D) g;
    int width = getWidth();
    int height = getHeight();

    // Puntos de inicio y fin del degradado (vertical)
    Point2D start = new Point2D.Float(0, 0);
    Point2D end = new Point2D.Float(0, height);

    // Tres colores: gris claro arriba, verde medio, gris claro abajo
    Color[] colores = {
        new Color(0, 0, 0),   // Gris claro (arriba)
        new Color(4, 143, 57),      // Verde (centro)
        new Color(0, 0, 0)    // Gris claro (abajo)
    };

    // Posiciones relativas: 0.0 = inicio, 1.0 = fin
    float[] posiciones = { 0.0f, 0.5f, 1.0f };

    // Crear y aplicar el degradado lineal
    LinearGradientPaint lgp = new LinearGradientPaint(start, end, posiciones, colores);
    g2d.setPaint(lgp);
    g2d.fillRect(0, 0, width, height);
        }
}   

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new jPanelGradient();
        jButton1 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        titulo = new javax.swing.JLabel();
        Ven_Anterior = new javax.swing.JButton();
        Ven_Siguiente = new javax.swing.JButton();

        setBackground(new java.awt.Color(153, 255, 153));
        setClosable(true);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setPreferredSize(new java.awt.Dimension(760, 720));

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setForeground(new java.awt.Color(0, 0, 0));

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setForeground(new java.awt.Color(0, 255, 153));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/interfaz_ii/image (1) (1).png"))); // NOI18N
        jButton1.setText("CARGAR ARCHIVO");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));

        jButton4.setBackground(new java.awt.Color(0, 0, 0));
        jButton4.setForeground(new java.awt.Color(0, 255, 153));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/interfaz_ii/image (1) (1).png"))); // NOI18N
        jButton4.setText("CARGAR AULAS Y SILLAS");
        jButton4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));

        jButton3.setBackground(new java.awt.Color(0, 0, 0));
        jButton3.setForeground(new java.awt.Color(0, 255, 153));
        jButton3.setText("ASIGNAR");
        jButton3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "", "", "", ""
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton2.setBackground(new java.awt.Color(0, 0, 0));
        jButton2.setForeground(new java.awt.Color(0, 255, 153));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/interfaz_ii/exportar (1).png"))); // NOI18N
        jButton2.setText("EXPORTAR");
        jButton2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        titulo.setFont(new java.awt.Font("Segoe UI Historic", 0, 18)); // NOI18N
        titulo.setForeground(new java.awt.Color(0, 255, 153));
        titulo.setText("ASIGNAR SILLAS");

        Ven_Anterior.setText("Anterior Ven.");
        Ven_Anterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Ven_AnteriorActionPerformed(evt);
            }
        });

        Ven_Siguiente.setText("Siquiente Vent.");
        Ven_Siguiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Ven_SiguienteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 719, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Ven_Anterior))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(53, 53, 53)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(208, 208, 208)
                                        .addComponent(jLabel1))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jButton4)
                                        .addGap(65, 65, 65)
                                        .addComponent(jButton3))))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(93, 93, 93)
                                .addComponent(titulo)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(Ven_Siguiente)
                                .addGap(34, 34, 34)))))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addComponent(jLabel1))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Ven_Anterior)
                            .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Ven_Siguiente))))
                .addGap(79, 79, 79)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(76, 76, 76))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
    modelo = (DefaultTableModel) jTable1.getModel(); // ← ¡Importante!

    int fila = 0;
    for (String[] est : estudiantes) {
        String nombreCompleto = est[0];
        String codigo = est[1];
        String colegio = est[2];
        String apellido = nombreCompleto.split(" ")[0]; // Primer apellido

        boolean asignado = false;

        for (Aula aula : aulasCargadas) {
            if (aula.puedeAsignar(colegio, apellido)) {
                int silla = aula.asignarSilla(colegio, apellido);
                if (silla != -1) {
                    modelo.setValueAt(aula.nombre, fila, modelo.findColumn("Aula"));
                    modelo.setValueAt(silla, fila, modelo.findColumn("Silla"));
                    asignado = true;
                    break;
                }
            }
        }

        if (!asignado) {
            modelo.setValueAt("SIN AULA", fila, modelo.findColumn("Aula"));
            modelo.setValueAt("SIN SILLA", fila, modelo.findColumn("Silla"));
        }

        fila++;
    }

    jTable1.setModel(modelo); // opcional, si el modelo ya está asignado no es necesario

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    try {
        // Agrupar por aula
        Map<String, List<Object[]>> datosAgrupados = new TreeMap<>(); // TreeMap para orden alfabético
        int filas = modelo.getRowCount();
        int columnas = modelo.getColumnCount();

        for (int i = 0; i < filas; i++) {
            Object[] fila = new Object[columnas];
            for (int j = 0; j < columnas; j++) {
                fila[j] = modelo.getValueAt(i, j);
            }

            String aula = fila[modelo.findColumn("Aula")].toString();
            datosAgrupados.computeIfAbsent(aula, k -> new ArrayList<>()).add(fila);
        }

        // Crear Excel
        Workbook workbook = new XSSFWorkbook();
        Sheet hoja = workbook.createSheet("Asignación");

        // Encabezados
        Row filaEncabezado = hoja.createRow(0);
        for (int i = 0; i < columnas; i++) {
            Cell celda = filaEncabezado.createCell(i);
            celda.setCellValue(modelo.getColumnName(i));
        }

        // Escribir filas agrupadas
        int filaExcel = 1;
        for (Map.Entry<String, List<Object[]>> entrada : datosAgrupados.entrySet()) {
            for (Object[] fila : entrada.getValue()) {
                Row row = hoja.createRow(filaExcel++);
                for (int i = 0; i < fila.length; i++) {
                    row.createCell(i).setCellValue(fila[i].toString());
                }
            }
        }

        // Guardar archivo
        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            if (!archivo.getName().toLowerCase().endsWith(".xlsx")) {
                archivo = new File(archivo.getAbsolutePath() + ".xlsx");
            }
            FileOutputStream out = new FileOutputStream(archivo);
            workbook.write(out);
            out.close();
            workbook.close();
            JOptionPane.showMessageDialog(this, "Archivo exportado correctamente.");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al exportar: " + e.getMessage());
        e.printStackTrace();
    }

    exportarTablaAExcel();

    }//GEN-LAST:event_jButton2ActionPerformed

    
    private JDesktopPane contenedor;

public asignarSilla(JDesktopPane contenedor) {
    initComponents();
    this.contenedor = contenedor;
}
    private void Ven_AnteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Ven_AnteriorActionPerformed
        Registro_Alum registro = new Registro_Alum(contenedor);
    contenedor.add(registro);

    // Centrado del InternalFrame
    int x = (contenedor.getWidth() - registro.getWidth()) / 2;
    int y = (contenedor.getHeight() - registro.getHeight()) / 2;
    registro.setLocation(x, y);

    registro.setVisible(true);
    try {
        registro.setSelected(true);
    } catch (java.beans.PropertyVetoException ex) {
        ex.printStackTrace();
    }
    this.dispose();

    }//GEN-LAST:event_Ven_AnteriorActionPerformed

    private void Ven_SiguienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Ven_SiguienteActionPerformed
        ReporteVisualAulas reporte = new ReporteVisualAulas(contenedor);
    contenedor.add(reporte);

    // Centrado del InternalFrame
    int x = (contenedor.getWidth() - reporte.getWidth()) / 2;
    int y = (contenedor.getHeight() - reporte.getHeight()) / 2;
    reporte.setLocation(x, y);

    reporte.setVisible(true);
    try {
        reporte.setSelected(true);
    } catch (java.beans.PropertyVetoException ex) {
        ex.printStackTrace();
    }
    this.dispose();



    }//GEN-LAST:event_Ven_SiguienteActionPerformed



// Otros métodos o componentes...

// MÉTODO NUEVO para exportar
private void exportarTablaAExcel() {
    JFileChooser fileChooser = new JFileChooser();
    int option = fileChooser.showSaveDialog(this);

    if (option == JFileChooser.APPROVE_OPTION) {
        File archivo = fileChooser.getSelectedFile();
        
        // Asegura que tenga la extensión .xlsx
        if (!archivo.getName().toLowerCase().endsWith(".xlsx")) {
            archivo = new File(archivo.toString() + ".xlsx");
        }

        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Asignación");

            // Escribe encabezados
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            Row header = sheet.createRow(0);
            for (int col = 0; col < model.getColumnCount(); col++) {
                Cell cell = header.createCell(col);
                cell.setCellValue(model.getColumnName(col));
            }

            // Escribe filas
            for (int row = 0; row < model.getRowCount(); row++) {
                Row fila = sheet.createRow(row + 1);
                for (int col = 0; col < model.getColumnCount(); col++) {
                    Cell cell = fila.createCell(col);
                    Object valor = model.getValueAt(row, col);
                    cell.setCellValue(valor != null ? valor.toString() : "");
                }
            }

            // Guarda el archivo
            FileOutputStream out = new FileOutputStream(archivo);
            workbook.write(out);
            out.close();

            JOptionPane.showMessageDialog(this, "Datos exportados correctamente a:\n" + archivo.getAbsolutePath());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al exportar: " + e.getMessage());
            e.printStackTrace();
        }
    }
}


    /**
     * @param args the command line arguments
     *
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         *
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(asignarSilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(asignarSilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(asignarSilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(asignarSilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form *
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new asignarSilla().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Ven_Anterior;
    private javax.swing.JButton Ven_Siguiente;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables
}
*/