/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package interfaz_ii;

import java.io.File;
import java.util.List;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import javax.swing.JDesktopPane;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author NOEMI
 */
 class Aula {
    String nombre;
    int capacidad;
    List<Aula> listaAulas = new ArrayList<>();
    List<Integer> sillas;
    Map<String, Integer> colegioCount = new HashMap<>();
    Map<String, List<Integer>> apellidoSillas = new HashMap<>();
    Map<String, List<Integer>> ubigeoSillas = new HashMap<>();
    public String getNombre() {
    return nombre;
}
public int getCapacidad() {
    return capacidad;
}
    public Aula(String nombre, int cantidadSillas) {
    this.nombre = nombre;
    this.capacidad = cantidadSillas; // ✅ importante
    this.sillas = new ArrayList<>();
    for (int i = 1; i <= cantidadSillas; i++) {
        sillas.add(i);
    }
    Collections.shuffle(sillas);
}
    public boolean puedeAsignar(String ubigeo, String apellido) {
        int countUbigeo = colegioCount.getOrDefault(ubigeo, 0);
        int countApellido = apellidoSillas.getOrDefault(apellido, new ArrayList<>()).size();

        if (countUbigeo >= 3 || countApellido >= 4) return false;

        for (int silla : sillas) {
            boolean lejanoApellido = apellidoSillas.getOrDefault(apellido, new ArrayList<>())
                .stream().allMatch(s -> Math.abs(s - silla) >= 3);
            boolean lejanoUbigeo = ubigeoSillas.getOrDefault(ubigeo, new ArrayList<>())
                .stream().allMatch(s -> Math.abs(s - silla) >= 3);
            if (lejanoApellido && lejanoUbigeo) return true;
        }
        return false;
    }

    public int asignarSilla(String ubigeo, String apellido) {
        for (int i = 0; i < sillas.size(); i++) {
            int silla = sillas.get(i);
            boolean lejanoApellido = apellidoSillas.getOrDefault(apellido, new ArrayList<>())
                .stream().allMatch(s -> Math.abs(s - silla) >= 3);
            boolean lejanoUbigeo = ubigeoSillas.getOrDefault(ubigeo, new ArrayList<>())
                .stream().allMatch(s -> Math.abs(s - silla) >= 3);

            if (lejanoApellido && lejanoUbigeo) {
                sillas.remove(i);
                colegioCount.put(ubigeo, colegioCount.getOrDefault(ubigeo, 0) + 1);
                apellidoSillas.computeIfAbsent(apellido, k -> new ArrayList<>()).add(silla);
                ubigeoSillas.computeIfAbsent(ubigeo, k -> new ArrayList<>()).add(silla);
                return silla;
            }
        }
        return -1;
    }

    public int asignarLibre() {
        if (!sillas.isEmpty()) return sillas.remove(0);
        return -1;
    }
}

public class asignarSilla_2 extends javax.swing.JInternalFrame {
private List<Aula> aulasCargadas = new ArrayList<>();
private List<String[]> estudiantes = new ArrayList<>();
private DefaultTableModel modelo;
private void cargarAulasDesdeExcel() {
    try {
        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            Workbook workbook;
            if (archivo.getName().endsWith(".xls")) {
                workbook = new HSSFWorkbook(new FileInputStream(archivo));
            } else if (archivo.getName().endsWith(".xlsx")) {
                workbook = new XSSFWorkbook(new FileInputStream(archivo));
            } else {
                JOptionPane.showMessageDialog(this, "Archivo no válido.");
                return;
            }

            Sheet hoja = workbook.getSheetAt(0);
            aulasCargadas.clear(); 

            for (int i = 1; i <= hoja.getLastRowNum(); i++) {
                Row fila = hoja.getRow(i);
                if (fila == null) continue;

                Cell celdaNombre = fila.getCell(0);
                Cell celdaCapacidad = fila.getCell(1);

                if (celdaNombre == null || celdaCapacidad == null) continue;

                String nombreAula = celdaNombre.toString().trim();
                int capacidad = 0;
    switch (celdaCapacidad.getCellType()) {
        case NUMERIC:
        capacidad = (int) celdaCapacidad.getNumericCellValue();
        break;
        case STRING:
        String valor = celdaCapacidad.getStringCellValue().trim();
        if (!valor.matches("\\d+")) {
        JOptionPane.showMessageDialog(this, "Error: Capacidad no válida en la fila " + (i + 1) + " → '" + valor + "'");
        continue;
        }
        capacidad = Integer.parseInt(valor);
        break;
        default:
        JOptionPane.showMessageDialog(this, "Tipo de dato no válido para capacidad en la fila " + (i + 1));
        continue;
}
                aulasCargadas.add(new Aula(nombreAula, capacidad));
            }

            workbook.close();
            JOptionPane.showMessageDialog(this, "Aulas cargadas correctamente.");
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al cargar aulas: " + e.getMessage());
        e.printStackTrace();
    } 
    
}

private void cargarArchivoExcel() {
    JFileChooser fileChooser = new JFileChooser();
    if (fileChooser.showOpenDialog(null) != JFileChooser.APPROVE_OPTION) return;
    File archivo = fileChooser.getSelectedFile();

    // Columnas que se van a mostrar del Excel: 0, 3, 1, 5, 12, 30, 31
    int[] cols = {0, 1, 2, 5, 12};

    modelo = (DefaultTableModel) jTable1.getModel();
    modelo.setRowCount(0);
    modelo.setColumnCount(0);

    try (FileInputStream fis = new FileInputStream(archivo)) {
        Workbook wb = WorkbookFactory.create(fis);
        Sheet sheet = wb.getSheetAt(0);

        // Agregar encabezados
        Row header = sheet.getRow(0);
        for (int idx : cols) {
            modelo.addColumn(header.getCell(idx).toString().trim());
        }

        // Agregar columnas para AULA y SILLA
        modelo.addColumn("Aula");
        modelo.addColumn("Silla");

        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            if (row == null) continue;

            Object[] datos = new Object[cols.length + 2]; // +2 para Aula y Silla
            for (int k = 0; k < cols.length; k++) {
                Cell c = row.getCell(cols[k], Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
               switch (c.getCellType()) {
    case STRING:
        datos[k] = c.getStringCellValue();
        break;
    case NUMERIC:
        double valor = c.getNumericCellValue();
        long valorEntero = (long) valor;
        // Si tiene 8 dígitos exactos, lo tratamos como DNI
        if (String.valueOf(valorEntero).length() == 8) {
            datos[k] = String.valueOf(valorEntero);
        } else {
            datos[k] = String.valueOf(valor);
        }
        break;
    case BOOLEAN:
        datos[k] = c.getBooleanCellValue();
        break;
    default:
        datos[k] = c.toString();
        break;
}

            }

            // Inicialmente Aula y Silla vacíos
            datos[cols.length] = "";
            datos[cols.length + 1] = "";

            modelo.addRow(datos);
        }

        JOptionPane.showMessageDialog(null, "Archivo cargado correctamente.");
    } catch (Exception ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al cargar el archivo:\n" + ex.getMessage());
    }
}

    /**
     * Creates new form asignarSilla
     */
    
  
    
     public asignarSilla_2(JDesktopPane contenedor) {
        initComponents();
        setClosable(true);
        setIconifiable(true);
        setResizable(false);
        setTitle("Asignar Silla");

    cargarArchivo.setText("CARGAR ARCHIVO");
    cargarArchivo.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            cargarArchivoExcel();
        }
    });

    cargarAulas.setText("CARGAR AULAS Y SILLAS");
    cargarAulas.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            cargarAulasDesdeExcel();
        }
    });

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        cargarArchivo = new javax.swing.JButton();
        cargarAulas = new javax.swing.JButton();
        jbuttonAsignar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        Exportar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 255, 153));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 204));
        jPanel2.setForeground(new java.awt.Color(255, 255, 153));
        jPanel2.setPreferredSize(new java.awt.Dimension(1144, 750));

        cargarArchivo.setBackground(new java.awt.Color(0, 204, 153));
        cargarArchivo.setForeground(new java.awt.Color(0, 0, 0));
        cargarArchivo.setText("CARGAR ARCHIVO");
        cargarArchivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cargarArchivoActionPerformed(evt);
            }
        });

        cargarAulas.setBackground(new java.awt.Color(0, 204, 153));
        cargarAulas.setForeground(new java.awt.Color(0, 0, 0));
        cargarAulas.setText("CARGAR AULAS Y SILLAS");

        jbuttonAsignar.setBackground(new java.awt.Color(0, 204, 153));
        jbuttonAsignar.setForeground(new java.awt.Color(0, 0, 0));
        jbuttonAsignar.setText("ASIGNAR");
        jbuttonAsignar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbuttonAsignarActionPerformed(evt);
            }
        });

        jTable1.setBackground(new java.awt.Color(153, 255, 153));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "", "", "", ""
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        Exportar.setBackground(new java.awt.Color(0, 204, 153));
        Exportar.setForeground(new java.awt.Color(0, 0, 0));
        Exportar.setText("EXPORTAR");
        Exportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExportarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(cargarArchivo, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(53, 53, 53)
                        .addComponent(cargarAulas))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(276, 276, 276)
                        .addComponent(jbuttonAsignar))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1366, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(Exportar, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cargarAulas, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cargarArchivo, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jbuttonAsignar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(Exportar, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(181, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(397, 397, 397))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void jbuttonAsignarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbuttonAsignarActionPerformed
    modelo = (DefaultTableModel) jTable1.getModel();

    int total = modelo.getRowCount();
    List<Integer> ordenIntercalado = new ArrayList<>();
    int i = 0, j = total - 1;

    while (i <= j) {
        if (i == j) ordenIntercalado.add(i);
        else {
            ordenIntercalado.add(i);
            ordenIntercalado.add(j);
        }
        i++; j--;
    }

    for (int fila : ordenIntercalado) {
      String nombreCompleto = modelo.getValueAt(fila, 2).toString().trim(); // Apellidos y nombres
String apellido = nombreCompleto.split(",")[0].trim();
String ubigeo = modelo.getValueAt(fila, 4).toString().trim(); // UBIGEO
String codigo = modelo.getValueAt(fila, 0).toString(); // Columna 1
String DNI = modelo.getValueAt(fila, 5).toString();

        boolean asignado = false;

        for (Aula aula : aulasCargadas) {
            if (aula.colegioCount.getOrDefault(ubigeo, 0) >= 3) continue;

            int countApellido = aula.apellidoSillas.getOrDefault(apellido, new ArrayList<>()).size();
            if (countApellido >= 4) continue;

            for (int silla : aula.sillas) {
                boolean lejanoApellido = aula.apellidoSillas.getOrDefault(apellido, new ArrayList<>())
                        .stream().allMatch(s -> Math.abs(s - silla) >= 3);
                boolean lejanoUbigeo = aula.ubigeoSillas.getOrDefault(ubigeo, new ArrayList<>())
                        .stream().allMatch(s -> Math.abs(s - silla) >= 3);

                if (lejanoApellido && lejanoUbigeo) {
                    modelo.setValueAt(aula.getNombre(), fila, modelo.getColumnCount() - 2); // AULA
                    modelo.setValueAt(silla, fila, modelo.getColumnCount() - 1);            // SILLA

                    aula.sillas.remove((Integer) silla);
                    aula.colegioCount.put(ubigeo, aula.colegioCount.getOrDefault(ubigeo, 0) + 1);
                    aula.apellidoSillas.computeIfAbsent(apellido, k -> new ArrayList<>()).add(silla);
                    aula.ubigeoSillas.computeIfAbsent(ubigeo, k -> new ArrayList<>()).add(silla);

                    asignado = true;
                    break;
                }
            }

            if (asignado) break;
        }

        if (!asignado) {
            modelo.setValueAt("SIN AULA", fila, modelo.getColumnCount() - 2);
            modelo.setValueAt("SIN SILLA", fila, modelo.getColumnCount() - 1);
        }
    }

    JOptionPane.showMessageDialog(null, "Asignación completada.");

    }//GEN-LAST:event_jbuttonAsignarActionPerformed

    private void ExportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExportarActionPerformed
    try {
        Map<String, List<Object[]>> datosAgrupados = new TreeMap<>(); // TreeMap para orden alfabético
        int filas = modelo.getRowCount();
        int columnas = modelo.getColumnCount();

        for (int i = 0; i < filas; i++) {
            Object[] fila = new Object[columnas];
            for (int j = 0; j < columnas; j++) {
                fila[j] = modelo.getValueAt(i, j);
            }

            String aula = fila[modelo.findColumn("Aula")].toString();
            datosAgrupados.computeIfAbsent(aula, k -> new ArrayList<>()).add(fila);
        }

        Workbook workbook = new XSSFWorkbook();
        Sheet hoja = workbook.createSheet("Asignación");

        Row filaEncabezado = hoja.createRow(0);
        for (int i = 0; i < columnas; i++) {
            Cell celda = filaEncabezado.createCell(i);
            celda.setCellValue(modelo.getColumnName(i));
        }

        int filaExcel = 1;
        for (Map.Entry<String, List<Object[]>> entrada : datosAgrupados.entrySet()) {
            for (Object[] fila : entrada.getValue()) {
                Row row = hoja.createRow(filaExcel++);
                for (int i = 0; i < fila.length; i++) {
                    row.createCell(i).setCellValue(fila[i].toString());
                }
            }
        }

        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            if (!archivo.getName().toLowerCase().endsWith(".xlsx")) {
                archivo = new File(archivo.getAbsolutePath() + ".xlsx");
            }
            FileOutputStream out = new FileOutputStream(archivo);
            workbook.write(out);
            out.close();
            workbook.close();
            JOptionPane.showMessageDialog(this, "Archivo exportado correctamente.");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al exportar: " + e.getMessage());
        e.printStackTrace();
    }
    }//GEN-LAST:event_ExportarActionPerformed

    private void cargarArchivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cargarArchivoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cargarArchivoActionPerformed

private void exportarTablaAExcel() {
    JFileChooser fileChooser = new JFileChooser();
    int option = fileChooser.showSaveDialog(this);

    if (option == JFileChooser.APPROVE_OPTION) {
        File archivo = fileChooser.getSelectedFile();
  
        if (!archivo.getName().toLowerCase().endsWith(".xlsx")) {
            archivo = new File(archivo.toString() + ".xlsx");
        }

        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Asignación");

            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            Row header = sheet.createRow(0);
            for (int col = 0; col < model.getColumnCount(); col++) {
                Cell cell = header.createCell(col);
                cell.setCellValue(model.getColumnName(col));
            }

            for (int row = 0; row < model.getRowCount(); row++) {
                Row fila = sheet.createRow(row + 1);
                for (int col = 0; col < model.getColumnCount(); col++) {
                    Cell cell = fila.createCell(col);
                    Object valor = model.getValueAt(row, col);
                    cell.setCellValue(valor != null ? valor.toString() : "");
                }
            }

            FileOutputStream out = new FileOutputStream(archivo);
            workbook.write(out);
            out.close();

            JOptionPane.showMessageDialog(this, "Datos exportados correctamente a:\n" + archivo.getAbsolutePath());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al exportar: " + e.getMessage());
            e.printStackTrace();
        }
    }
}


    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(asignarSilla_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(asignarSilla_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(asignarSilla_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(asignarSilla_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
      
}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Exportar;
    private javax.swing.JButton cargarArchivo;
    private javax.swing.JButton cargarAulas;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton jbuttonAsignar;
    // End of variables declaration//GEN-END:variables

  
    public void setSelected(boolean selected) throws java.beans.PropertyVetoException {
    super.setSelected(selected);
}
}
